using Microsoft.EntityFrameworkCore;
public class DbParole : DbContext
	{
		public DbSet<Parola> Parole { get; set; }
		public DbParole (DbContextOptions<DbParole> options)
			: base(options)
		{
		}
	}