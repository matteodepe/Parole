using System.ComponentModel.DataAnnotations;
public class Parola
{
	public int IDParola{ get; set; }
	public string Nome{get;set;}
    public string Descrizione { get; set; }


    
		public override string ToString() 
		=> $"{IDParola} \t{Descrizione} {Nome}";
	}