using System.ComponentModel.DataAnnotations;
public class Scelta
{
	public int IDScelta{ get; set; }
	public string Significato{get;set;}
  
		public override string ToString() 
		=> $"{IDScelta} \t{Significato} ";
	}